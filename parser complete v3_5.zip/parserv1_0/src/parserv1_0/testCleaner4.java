
package parserv1_0;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

public class testCleaner4 {
	public static void main(String[] args) throws IOException {
		String input=readFile("output2.txt");
		File logFile = new File("output3.txt");
		PrintWriter output = new PrintWriter(logFile);
	//moving
		
		int i=-1;
//		System.out.println(input+"\n----------&&&&&&&&&&&&&&&&&&&&&&&&&\n\n");
		String text[]=new String[60];
		String pos[]=new String[60];
		String lemma[]=new String[60];
		String senti[]=new String[60];
		String sroot;
		String dependency[]=new String[150];
		int dependencyCounter=0;
		int d1[]=new int[150];
		int d2[]=new int[150];
		int ax,ay;
		String sentence;	//entire sentence
		String Ssenti; // neg,neutral,positive
		String filename;
		
				
		while(input.indexOf("Sentence #",i)!=-1)
		{
			int first=input.indexOf("Sentence #",i);
			int t=input.indexOf("(",first);
			int last=input.indexOf("token",t);
			int noToken=Integer.parseInt(input.substring(t+1, last-1));
			int a=0;
			int j=first;
			//sentence sentiment
			
			
			int start=input.indexOf(": ",j);
			int end=input.indexOf("):",start);
			Ssenti=input.substring(start+2,end);
			//Entire sentence
			start=input.indexOf("):",j);
			end=input.indexOf("[",start);
			sentence=input.substring(start+3,end-1);
//			System.out.println("----------\n"+noToken);
//			System.out.println(first+"\t"+last)
			start=input.indexOf("[",j);
			end=input.indexOf("]",start);
			filename=input.substring(input.indexOf("=",j)+1,end);
//			System.out.println("This is the answer\t"+filename);
			j=end+1;
			System.out.println(sentence+"\n"+filename+"\t"+Ssenti);
			while(a<noToken)
			{
				//text
				start=input.indexOf("[",j);
				end=input.indexOf("PartOf",start);
				text[a]=input.substring(input.indexOf("=",j)+1,end-1);
				j=end;
				//pos
				start=input.indexOf("=",j);
				end=input.indexOf("Lemma",start);
				pos[a]=input.substring(input.indexOf("=",j)+1,end-1);
				j=end;
				//Lemma
				start=input.indexOf("=",j);
				end=input.indexOf("Senti",start);
				lemma[a]=input.substring(input.indexOf("=",j)+1,end-1);
				j=end;
				//Sentiment
				start=input.indexOf("=",j);
				end=input.indexOf("]",start);
				senti[a]=input.substring(input.indexOf("=",j)+1,end);
				j=end;
				
				
				System.out.println(text[a]+"\t"+pos[a]+"\t"+lemma[a]+"\t"+senti[a]+"\t");
				a++;
			}
			i=j;
			//dependency starts here
			dependencyCounter=0;
				start=input.indexOf("root(",j);
				end=input.indexOf("Sentence #",i);
				j=input.indexOf("(",start);
				sroot=input.substring(start,j);
				i=input.indexOf("-",j);
				j=input.indexOf(",",j);
				ax=Integer.parseInt(input.substring(i+1,j));
				i=input.indexOf("-",j);
				j=input.indexOf(")",j);
				ay=Integer.parseInt(input.substring(i+1,j));
				System.out.println("\n"+sroot+"\t"+ax+"\t"+ay);	
				i=j;
				
				while(input.indexOf("(",i)!=-1&&input.indexOf("(",i)<end)		
				{
					
					try{
						
					
						i=input.indexOf("\n",i);
						i++;
						j=input.indexOf("(",j);
						dependency[dependencyCounter++]=input.substring(i,j);
						i=input.indexOf("-",j);
						j=input.indexOf(",",j);
						d1[dependencyCounter-1]=Integer.parseInt(input.substring(i+1,j));
						i=input.indexOf("-",j);
						j=input.indexOf(")",j);
						d2[dependencyCounter-1]=Integer.parseInt(input.substring(i+1,j));
					}
					catch(NumberFormatException e)
					{
						
					}
					System.out.println("\n"+dependency[dependencyCounter-1]+"\t"+d1[dependencyCounter-1]+"\t"+d2[dependencyCounter-1]);	
						
					i=j;
							
				}	
			
			System.out.println("------");
			
			
		}
		
		
		
		
	//	System.out.println(input);
		output.println(input);
		output.close();
			
			
		
			
		}
		
	static String readFile(String fileName) throws IOException {
	    BufferedReader br = new BufferedReader(new FileReader(fileName));
	    try {
	        StringBuilder sb = new StringBuilder();
	        String line = br.readLine();

	        while (line != null) {
	            sb.append(line);
	            sb.append("\n");
	            line = br.readLine();
	        }
	        return sb.toString();
	    } finally {
	        br.close();
	    }
	}
}
