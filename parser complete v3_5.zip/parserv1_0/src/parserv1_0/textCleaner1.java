package parserv1_0;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

public class textCleaner1 {

	public static void main(String[] args) throws IOException {
		String input=readFile("output.txt");
		File logFile = new File("output1.txt");
		PrintWriter output = new PrintWriter(logFile);
	//	System.out.println(""+input.charAt(843)+""+input.charAt(844)+""+input.charAt(845));
//	System.out.println(input);
		//for (ROOT
	while(input.indexOf("(ROOT\n")!=-1)
	{
		int first=input.indexOf("(ROOT\n");
		int last=input.indexOf("root(ROOT",first);
	//	System.out.println(first);
		if(last==-1)
			last=input.length()-1;
		String temp=input.substring(first, last);
		input = input.replace(temp,"\n");
	}
	
	//for CharacterOffset
	while(input.indexOf("CharacterOffsetBegin")!=-1)
	{
		int first=input.indexOf("CharacterOffsetBegin");
		int last=input.indexOf("PartOfSpeech",first);
	//	System.out.println(first);
		if(last==-1)
			last=input.length()-1;
		String temp=input.substring(first, last);
		input = input.replace(temp,"");
	}
	

	System.out.println(input);
	output.println(input);
	output.close();
		
		
	
	}
	
	
	
	
	
	
	
	static String readFile(String fileName) throws IOException {
	    BufferedReader br = new BufferedReader(new FileReader(fileName));
	    try {
	        StringBuilder sb = new StringBuilder();
	        String line = br.readLine();

	        while (line != null) {
	            sb.append(line);
	            sb.append("\n");
	            line = br.readLine();
	        }
	        return sb.toString();
	    } finally {
	        br.close();
	    }
	}
	
	
}
