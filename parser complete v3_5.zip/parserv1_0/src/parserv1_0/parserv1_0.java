package parserv1_0;
import java.io.*;
import java.util.*;
import edu.stanford.nlp.dcoref.CorefChain;
import edu.stanford.nlp.dcoref.CorefCoreAnnotations;
import edu.stanford.nlp.io.*;
import edu.stanford.nlp.ling.*;
import edu.stanford.nlp.pipeline.*;
import edu.stanford.nlp.semgraph.SemanticGraph;
import edu.stanford.nlp.semgraph.SemanticGraphCoreAnnotations;
import edu.stanford.nlp.sentiment.SentimentCoreAnnotations;
import edu.stanford.nlp.trees.*;
import edu.stanford.nlp.util.*;
public class parserv1_0 {


public static void main(String[] args) throws IOException {
	
	
	
	//trying out file handling
	File logFile = new File("output.txt");
	PrintWriter log_file_writer = new PrintWriter(logFile);
	//	log_file_writer.println("TEXT");
	String inputname="input.txt";
	String input=readFile(inputname);
    PrintWriter out;
    //out decides where to print the output
    
    if (args.length > 1) {
      out = new PrintWriter(args[1]);
    } else {
      out = new PrintWriter(System.out);
    }
    /*
    PrintWriter xmlOut = null;
    if (args.length > 2) {
      xmlOut = new PrintWriter(args[2]);
    }
    */

    // taking input here!!!!@
 //   Scanner sc=new Scanner(System.in);
//    System.out.println("Enter text here:\n");
    String inputText=input;
    

    // Add in sentiment
    Properties props = new Properties();
    //this next line decides what all you want! i don't freaking understand  y its not working without tokenizing!
  //  props.put("annotators", "tokenize, ssplit, pos, lemma, ner, parse, dcoref, sentiment");

    props.put("annotators", "tokenize, ssplit, pos, lemma, parse, sentiment");
    StanfordCoreNLP pipeline = new StanfordCoreNLP(props);

    // Initialize an Annotation with some text to be annotated. The text is the argument to the constructor.
    Annotation annotation;
    if (args.length > 0) {
      annotation = new Annotation(IOUtils.slurpFileNoExceptions(args[0]));
    } else {
    	
    	//adding the input here!
      annotation = new Annotation(inputText);
    }

    // run all the selected Annotators on this text
    pipeline.annotate(annotation);
    log_file_writer.println("$$FILENAME="+inputname+"$$\n");
    // this prints out the results of sentence analysis to file(s) in good formats
    pipeline.prettyPrint(annotation, log_file_writer);
    pipeline.prettyPrint(annotation, out);
    //closing Scanner
    //closing the file
    log_file_writer.close();
   // sc.close();
  }


//second method
static String readFile(String fileName) throws IOException {
    BufferedReader br = new BufferedReader(new FileReader(fileName));
    try {
        StringBuilder sb = new StringBuilder();
        String line = br.readLine();

        while (line != null) {
            sb.append(line);
            sb.append("\n");
            line = br.readLine();
        }
        return sb.toString();
    } finally {
        br.close();
    }
}


}

