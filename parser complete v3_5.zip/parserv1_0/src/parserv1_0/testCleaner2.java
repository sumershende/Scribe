package parserv1_0;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

public class testCleaner2 {
	public static void main(String[] args) throws IOException {
		String input=readFile("output1.txt");
		File logFile = new File("output2.txt");
		PrintWriter output = new PrintWriter(logFile);
	//for filename
		int i=-1;
	//	System.out.println(input+"\n----------");
		while(input.indexOf("$$FILE",i)!=-1)
		{
			int first=input.indexOf("$$FILE",i);
			int last=input.indexOf("$$\n",first);
//			System.out.println(first+"\t"+last);
			if(last==-1)
				last=input.length()-1;
			String temp=input.substring(first+2, last);
//			System.out.println(temp);
			//for sentence nested filename
			while(input.indexOf("Sentence #",last)!=-1)
			{
				int first1=input.indexOf("Sentence #",last);
				int last1=input.indexOf("[Text",first1);
			//	System.out.println(first1);
				if(last==-1)
					last=input.length()-1;

	//			System.out.println(first1+"\t"+last1);
				String temp1=input.substring(first1, last1);
				String temp2=temp1;

	//			System.out.println("---temp1=  "+temp1);
				input = input.replace(temp1,temp2+"["+temp+"]\n");
				i=first1+2;
				last=last1;
			}
			
			
			input = input.replace("$$"+temp+"$$","");
		}
		
		
		
		
		System.out.println(input);
		output.println(input);
		output.close();
			
			
		
			
		}
		
	static String readFile(String fileName) throws IOException {
	    BufferedReader br = new BufferedReader(new FileReader(fileName));
	    try {
	        StringBuilder sb = new StringBuilder();
	        String line = br.readLine();

	        while (line != null) {
	            sb.append(line);
	            sb.append("\n");
	            line = br.readLine();
	        }
	        return sb.toString();
	    } finally {
	        br.close();
	    }
	}
}
