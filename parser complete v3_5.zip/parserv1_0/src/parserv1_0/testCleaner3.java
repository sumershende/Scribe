package parserv1_0;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

public class testCleaner3 {
	public static void main(String[] args) throws IOException {
		String input=readFile("output2.txt");
		File logFile = new File("output3.txt");
		PrintWriter output = new PrintWriter(logFile);
	//moving
		
		int i=-1;
//		System.out.println(input+"\n----------&&&&&&&&&&&&&&&&&&&&&&&&&\n\n");
		String text[]=new String[60];
		String pos[]=new String[60];
		String lemma[]=new String[60];
		String senti[]=new String[60];
		String sentence;	//entire sentence
		String Ssenti; // neg,neutral,positive
		String filename;
				
		while(input.indexOf("Sentence #",i)!=-1)
		{
			int first=input.indexOf("Sentence #",i);
			int t=input.indexOf("(",first);
			int last=input.indexOf("token",t);
			int noToken=Integer.parseInt(input.substring(t+1, last-1));
			int a=0;
			int j=first;
			//sentence sentiment
			
			
			int start=input.indexOf(": ",j);
			int end=input.indexOf("):",start);
			Ssenti=input.substring(start+2,end);
			//Entire sentence
			start=input.indexOf("):",j);
			end=input.indexOf("[",start);
			sentence=input.substring(start+3,end-1);
//			System.out.println("----------\n"+noToken);
//			System.out.println(first+"\t"+last)
			start=input.indexOf("[",j);
			end=input.indexOf("]",start);
			filename=input.substring(input.indexOf("=",j)+1,end);
//			System.out.println("This is the answer\t"+filename);
			j=end+1;
			System.out.println(sentence+"\n"+filename+"\t"+Ssenti);
			while(a<noToken)
			{
				//text
				start=input.indexOf("[",j);
				end=input.indexOf("PartOf",start);
				text[a]=input.substring(input.indexOf("=",j)+1,end-1);
				j=end;
				//pos
				start=input.indexOf("=",j);
				end=input.indexOf("Lemma",start);
				pos[a]=input.substring(input.indexOf("=",j)+1,end-1);
				j=end;
				//Lemma
				start=input.indexOf("=",j);
				end=input.indexOf("Senti",start);
				lemma[a]=input.substring(input.indexOf("=",j)+1,end-1);
				j=end;
				//Sentiment
				start=input.indexOf("=",j);
				end=input.indexOf("]",start);
				senti[a]=input.substring(input.indexOf("=",j)+1,end);
				j=end;
				
				
				System.out.println(text[a]+"\t"+pos[a]+"\t"+lemma[a]+"\t"+senti[a]+"\t");
				a++;
			}
			i=j;
			
			System.out.println("------");
			
			
		}
		
		
		
		
	//	System.out.println(input);
		output.println(input);
		output.close();
			
			
		
			
		}
		
	static String readFile(String fileName) throws IOException {
	    BufferedReader br = new BufferedReader(new FileReader(fileName));
	    try {
	        StringBuilder sb = new StringBuilder();
	        String line = br.readLine();

	        while (line != null) {
	            sb.append(line);
	            sb.append("\n");
	            line = br.readLine();
	        }
	        return sb.toString();
	    } finally {
	        br.close();
	    }
	}
}
