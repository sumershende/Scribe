#!/bin/sh

java -jar dependencyviewer-runnable.jar "$@"
